<?php

$ticket = "xxxxxxxxxx";
$meid = "xxxxxxxxxx";
$os="xxxxxxxxxx";
$sign="xxxxxxxxxx";